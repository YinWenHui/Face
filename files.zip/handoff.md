# AestheteAI — Project Handoff
**File:** `aesthetic-crm.html` (single-file prototype, 1385 lines)  
**Date:** 2026-05-31  
**Owner:** Wen Hui (Industrial Digital Architect, Delta Electronics Thailand)  
**Context:** Thailand–China Medical Aesthetics & Plastic Surgery CRM  

---

## What This Is

A fully self-contained single HTML file prototype of a **luxury medical aesthetics CRM** with:
- 8 navigable panel system (no router, CSS `display` toggle)
- 3D parametric face customization (Three.js r128, WebGL)
- Thai / Chinese / English UI scaffold
- Static mock data (no backend yet)

Design system: Notion × Linear × Stripe — soft white/gold/navy palette.

---

## Tech Stack (Current File)

| Layer | What | Version |
|---|---|---|
| 3D | Three.js | r128 (CDN) |
| Charts | Chart.js | 3.9.1 (CDN) |
| Fonts | Cormorant Garamond + DM Sans | Google Fonts |
| Backend | None yet | — |
| Auth | None yet | — |
| Storage | None yet | — |

**Target production stack:** Next.js + React + Tailwind + Supabase + PostgreSQL

---

## File Structure (HTML)

```
<head>
  Three.js r128 CDN
  CSS variables + all styles (inline)

<body>
  .sidebar          → nav, 9 items, active state
  .main
    .topbar         → title, lang toggle (TH/ZH/EN), + New Patient
    .content
      #panel-dashboard    → KPIs, upcoming procedures, follow-up queue, charts
      #panel-patients     → searchable table, 6 mock patients
      #panel-profile      → 6-tab patient EMR (Overview/Medical/Aesthetic/Consent/FollowUp/Files)
      #panel-studio       → 3D Face Studio (Three.js canvas + sliders)
      #panel-workflow     → Kanban: Inquiry→Consultation→Pre-Op→Procedure→Recovery→Follow-Up
      #panel-beforeafter  → Before/After photo grid
      #panel-sales        → Revenue breakdown, outstanding payments
      #panel-tourism      → Package cards (Bangkok Beauty / Luxury V-Line), group bookings
      #panel-ai           → TH↔ZH↔EN translation, template library, AI note generator
  #new-patient-modal → 4-tab registration form

<script>
  Chart.js 3.9.1 CDN
  All JS inline
```

---

## JavaScript Architecture

### Navigation
```js
showPanel(id, el)         // switches active panel, triggers lazy inits
switchTab(el, targetId)   // profile sub-tabs and modal tabs
openNewPatient()          // modal open
closeModal()              // modal close
savePatient()             // stub — alert only
setLang(l, el)            // TH/ZH/EN toggle (UI only, no i18n wired)
```

### Patient Data
```js
const patients = [...]    // 6 mock objects
initPatients()            // renders #patient-tbl
```

### Charts
```js
let chartsInit = false
initCharts()              // lazy, called on dashboard show
                          // doughnut: proc mix, line: revenue trend
```

### Face Studio (Three.js)
```js
// State object — all Three.js refs here
let FS = {
  scene, camera, renderer, faceGroup,
  animId, autoRot, dragging, prev
}

// Morph params — 13 sliders
const faceParams = {
  jawW, chinL, cheekV, templeW,   // face shape
  eyeS, eyeTilt, eyeGap,          // eyes
  noseH, noseW, noseTip,          // nose
  upperLip, lowerLip, lipW        // lips
}

let skinColor = '#FDDBB4'         // hex skin tone

// Functions
initFaceStudio()    // called via setTimeout(80ms) after panel shows
fsAnimate()         // RAF loop
buildFace()         // destroys + rebuilds all Three.js geometry from faceParams
updateFace(param, val, el)   // slider oninput handler
setSkinTone(color, el)       // color dot click
resetFace()                  // reset all params to 1.0
toggleRotate()               // FS.autoRot toggle
toggleChip(el)               // procedure overlay chip toggle
saveConsultation()           // stub — alert
runAIAnalysis()              // updates .ai-bubble innerHTML (stub)
```

### Critical Three.js Notes
- **r128** — `CapsuleGeometry` does NOT exist. Use `CylinderGeometry` or `TubeGeometry`.
- **Canvas sizing bug** — `initFaceStudio` MUST run after panel layout. Use `setTimeout(initFaceStudio, 80)` minimum.
- **Face build** uses per-vertex sculpting on 48×48 `SphereGeometry` for cranium morphs.
- **Eyebrows, nose bridge, lips** use `TubeGeometry` along `CatmullRomCurve3`.
- **`buildFace()` guard** — always check `if(!FS.scene) return` at top.
- **`mouseup` on `window`** not canvas — prevents drag-lock on fast moves.

---

## CSS Design Tokens

```css
--gold: #B8955A          /* primary accent */
--gold-light: #D4AF74
--gold-pale: #F5EDD6     /* bg tint for gold items */
--navy: #0D1B2A          /* sidebar bg */
--navy-mid: #1A2E42
--bg: #F8F7F4            /* page bg */
--bg-card: #FFFFFF
--bg-subtle: #F2F0EB     /* input/hover bg */
--border: #E8E4DC
--text: #1A1A1A
--text-soft: #8A8A8A
--success: #2D7A4F
--warn: #C47B1A
--danger: #B03030
--radius: 12px
--radius-sm: 8px
```

Badge classes: `.badge-gold` `.badge-green` `.badge-blue` `.badge-red` `.badge-gray` `.badge-purple`

---

## Modules Status

| Module | UI | Data | Logic | Backend |
|---|---|---|---|---|
| Dashboard | ✅ | Mock | Charts live | ❌ |
| Patients | ✅ | 6 mock | Table render | ❌ |
| Patient Profile | ✅ | 1 mock (Li Mingzhi) | Tabs | ❌ |
| Face Studio | ✅ | — | 3D morph | ❌ |
| Workflow | ✅ | Mock cards | Kanban display | ❌ |
| Before/After | ✅ | Placeholder | Gallery | ❌ |
| Sales | ✅ | Mock | Revenue bars | ❌ |
| Tourism | ✅ | 2 packages | Cards | ❌ |
| AI Assist | ✅ stub | — | Translation stub | ❌ |
| New Patient Form | ✅ 4-tab | — | Alert only | ❌ |
| Auth | ❌ | — | — | ❌ |
| i18n (TH/ZH/EN) | UI only | — | — | ❌ |

---

## Known Issues / Bugs Fixed

| Bug | Fix Applied |
|---|---|
| `THREE.CapsuleGeometry is not a constructor` (r128) | Replaced with `CylinderGeometry` / `TubeGeometry` |
| Black canvas on Face Studio open | `setTimeout(80ms)` defers init until after panel layout paint |
| `clientWidth = 0` during init | Use `offsetWidth` with `Math.max(..., 300)` fallback |
| `THREE.THREE` accidental reference in lip array | Removed, cleaned filter |
| Drag lock on fast mouse moves | `mouseup` listener moved to `window` |
| Charts re-init crash | `chartsInit` bool guard |

---

## Next Steps (Prioritized)

### P0 — Face Studio Polish
- [ ] Face is built but may still appear blank on some browsers — add a test sphere first on init to confirm WebGL works
- [ ] Add MorphTarget animation instead of full rebuild on slider move (performance)
- [ ] Add hair options (color + style geometry)
- [ ] Add gender toggle (male/female baseline mesh)
- [ ] Add age slider (skin texture opacity, jowl sag)
- [ ] Procedure overlay: highlight zones on face in gold when chip is toggled

### P1 — CRM Features
- [ ] Wire New Patient form → real data (Supabase)
- [ ] Patient list search/filter (live)
- [ ] Patient → Profile navigation (pass patient ID, render correct data)
- [ ] Before/After: real image upload + side-by-side compare
- [ ] Follow-up: real scheduler with date triggers
- [ ] Consent: PDF generation + e-signature

### P2 — AI Integration
- [ ] Wire AI Assist translation panel → Claude API (`claude-sonnet-4-6`)
- [ ] EMR note auto-generation from consultation transcript
- [ ] Photo upload → facial measurement AI analysis
- [ ] Procedure recommendation from face measurements

### P3 — Production
- [ ] Port to Next.js 14 App Router
- [ ] Supabase auth (email + LINE OAuth)
- [ ] Supabase DB schema (patients, procedures, followups, consents, photos)
- [ ] Cloud image storage (Supabase Storage or Cloudflare R2)
- [ ] WeChat / LINE webhook integration for auto follow-up
- [ ] i18n: react-intl or next-intl (TH/ZH/EN)
- [ ] Role-based access: coordinator / surgeon / translator / admin

---

## Supabase Schema Draft

```sql
-- patients
id uuid PK, created_at, clinic_id,
name_th, name_zh, name_en, nickname,
dob, gender, nationality, passport,
phone, line_id, wechat_id, whatsapp, email,
emergency_contact, occupation,
tag (vip/gold/regular/tourism),
referral_source, coordinator_id

-- medical_risk
patient_id FK, drug_allergies text[],
conditions jsonb, medications text,
smoking, alcohol, anesthesia_notes

-- aesthetic_history
patient_id FK, procedure text, clinic text,
date, implant_material, notes, satisfaction int

-- procedures (internal)
id, patient_id FK, type, surgeon_id,
scheduled_at, status, price, deposit_paid, notes

-- followups
id, patient_id FK, procedure_id FK,
due_date, channel (line/wechat/whatsapp),
template_key, sent_at, status

-- photos
id, patient_id FK, procedure_id FK,
type (before/after/progress), url, taken_at, ai_analysis jsonb

-- packages (tourism)
id, name, description_th, description_zh,
price_thb, inclusions jsonb, active bool
```

---

## Design Reference

- Sidebar: navy `#0D1B2A` + gold accent
- Typography: Cormorant Garamond (headings/metrics) + DM Sans (UI)
- Spacing: 8px base grid
- Cards: white bg, 1px `#E8E4DC` border, `border-radius: 12px`, subtle shadow
- Reference apps: Notion, Linear, Stripe Dashboard

---

## Session Log

| Date | Work |
|---|---|
| 2026-05-31 | Initial build — full 8-panel CRM + Face Studio v1 (primitive geometry) |
| 2026-05-31 | Face Studio v2 — per-vertex cranium sculpt, tube eyebrows/nose/lips |
| 2026-05-31 | Bug fixes — CapsuleGeometry, black canvas, THREE.THREE, mouseup |
| 2026-05-31 | This handoff generated |

---

## How to Continue

1. Open `aesthetic-crm.html` in browser — all 8 panels work except Face Studio may still render blank (check console for errors first)
2. For Face Studio debug: open browser console → navigate to Face Studio → look for JS errors
3. If blank: add `console.log('FS.scene', FS.scene, 'faceGroup', FS.faceGroup)` inside `fsAnimate` to confirm objects exist
4. Next major task: **port to React/Next.js** — each `#panel-*` becomes a route/page component

**To load context in a new Claude session**, paste this file + say:  
*"Continue AestheteAI CRM. Current file is aesthetic-crm.html (1385 lines). Read the handoff.md for full context."*
